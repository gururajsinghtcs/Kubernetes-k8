1. Create Builder Image
2. Create Service Account
3. Install Plugins
    3.1 Kubernetes
    3.2 jfrog
    3.3 docker
    3.4 maven
    3.5 git
4. Credentials
   Bitbucket - ssh keys (in the image)
   jfrog - admin / Admin123 dptprojectspr@gmail.com / Admin@123
   docker - dpthub / HubD0ck3R
6.  